package com.smartkhata.auth.entity;

public enum Role {
    OWNER,
    STAFF
}
